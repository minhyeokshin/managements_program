create
    definer = ssg@localhost procedure whileProcgugu()
BEGIN
   DECLARE i int;
   DECLARE j int;
   DECLARE str VARCHAR(100);

   set i = 2;

   WHILE(i < 10) DO  -- 2단 ~ 9단까지

    SET j = 1;
   WHILE(j<10) DO
           set str = concat(i,' x ',j,' = ',i*j);
           INSERT INTO guguTBL VALUES (str);
           set j = j+1;
   END WHILE;

      set i = i + 1;

       END WHILE;

END;


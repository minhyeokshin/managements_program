create
    definer = ssg@localhost procedure cursorProc()
BEGIN
    DECLARE userHeight INT;
    DECLARE cnt INT DEFAULT 0;
    DECLARE totalheight INT DEFAULT 0;

    DECLARE endOfRow BOOLEAN DEFAULT FALSE;

    DECLARE userCursor CURSOR FOR
        SELECT height FROM usertbl;
    DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET endOfRow = TRUE;
    OPEN userCursor;

    cursor_loop: LOOP
        FETCH userCursor INTO userHeight;

        IF endOfRow THEN
            LEAVE cursor_loop;
        end if;

        SET cnt = cnt + 1;
        SET totalheight = totalheight + userHeight;
    end loop cursor_loop;

    SELECT concat('고객 키의 평균 => ',format(totalheight/cnt,2)) as '평균 키';

    CLOSE userCursor;
end;


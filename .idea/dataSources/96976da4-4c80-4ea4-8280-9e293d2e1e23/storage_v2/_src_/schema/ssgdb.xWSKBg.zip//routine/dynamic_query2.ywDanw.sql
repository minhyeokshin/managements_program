create
    definer = ssg@localhost procedure dynamic_query2(IN t_name varchar(50), IN c_name varchar(50), IN b_year int,
                                                     IN height int)
BEGIN
    SET @t_name2 = t_name;
    SET @c_name2 = c_name;
    SET @b_year = b_year;
    SET @height = height;
    SET @sql2 = concat('SELECT ',@c_name2,' FROM ',@t_name2,' WHERE birthYear > ',' @b_year',' and ','height > ','@height');

    SELECT @sql2;
    PREPARE dynamic_query2 FROM @sql2;
    EXECUTE dynamic_query2;
    DEALLOCATE PREPARE dynamic_query2;

end;


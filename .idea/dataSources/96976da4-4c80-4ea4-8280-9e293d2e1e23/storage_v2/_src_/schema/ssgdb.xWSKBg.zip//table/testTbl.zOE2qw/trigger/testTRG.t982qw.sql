create definer = ssg@localhost trigger testTRG
    after delete
    on testTbl
    for each row
BEGIN
    SET @msg = '가수 그룹이 삭제됨';
end;


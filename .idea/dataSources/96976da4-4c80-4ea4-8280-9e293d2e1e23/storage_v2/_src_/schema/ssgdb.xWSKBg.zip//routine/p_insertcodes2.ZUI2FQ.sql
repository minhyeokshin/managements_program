create
    definer = ssg@localhost procedure p_insertcodes2(IN userID varchar(255), IN userPW varchar(255),
                                                     IN useremail varchar(255), IN hp varchar(255), IN date datetime,
                                                     IN point int, IN resultMsg varchar(255))
BEGIN
    -- 쿼리문 작성
    SET @strsql = CONCAT('INSERT INTO TB_MEMBER', ' (m_userid, m_pwd, m_email, m_hp, m_registdate, m_point) ');

    -- 바인딩할 변수 설정
    SET @ID = userID;
    SET @PW = userPW;
    SET @email = useremail;
    SET @hp = hp;
    SET @DATE = now();
    SET @POINT = point;
    SET resultMsg = 'Insert Success';

    PREPARE stmt FROM @strsql;
    EXECUTE stmt using @ID;
    EXECUTE stmt using @PW;
    EXECUTE stmt using @email;
    EXECUTE stmt using @hp;
    EXECUTE stmt using @POINT;
    EXECUTE stmt using @resultMsg;
    deallocate prepare stmt;

    -- 트랜잭션 확정

    COMMIT;

END;


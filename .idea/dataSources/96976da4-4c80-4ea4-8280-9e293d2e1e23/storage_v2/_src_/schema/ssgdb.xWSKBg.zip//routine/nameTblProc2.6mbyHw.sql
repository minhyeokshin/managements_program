create
    definer = ssg@localhost procedure nameTblProc2(IN tblname varchar(20))
BEGIN
    SET @sqlQuery = concat('SELECT * FROM ', tblname);
    PREPARE myQuery FROM @sqlQuery;
    EXECUTE myQuery;
    deallocate PREPARE myQuery;

END;


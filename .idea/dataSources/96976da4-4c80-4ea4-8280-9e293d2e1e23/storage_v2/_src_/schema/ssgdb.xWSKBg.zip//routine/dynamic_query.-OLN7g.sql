create
    definer = ssg@localhost procedure dynamic_query(IN t_name varchar(50), IN c_name varchar(50),
                                                    IN user_name varchar(50))
BEGIN
    SET @t_name = t_name;
    SET @c_name = c_name;
    SET @user_name = user_name;
    SET @sql = concat('SELECT ',@c_name,' FROM ',@t_name,' WHERE name = ','@user_name');

    SELECT @sql;
    PREPARE dynamic_query FROM @sql;
    EXECUTE dynamic_query;
    DEALLOCATE PREPARE dynamic_query;

end;


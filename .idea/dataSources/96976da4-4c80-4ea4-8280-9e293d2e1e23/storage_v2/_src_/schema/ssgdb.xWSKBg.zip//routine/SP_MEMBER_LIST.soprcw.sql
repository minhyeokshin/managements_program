create
    definer = ssg@localhost procedure SP_MEMBER_LIST()
BEGIN
    SET @sqlquery = 'SELECT * FROM TB_MEMBER;';
#     SELECT @sqlquery;
#
    PREPARE stmt FROM @sqlquery;
    EXECUTE stmt;
    deallocate prepare stmt;

end;


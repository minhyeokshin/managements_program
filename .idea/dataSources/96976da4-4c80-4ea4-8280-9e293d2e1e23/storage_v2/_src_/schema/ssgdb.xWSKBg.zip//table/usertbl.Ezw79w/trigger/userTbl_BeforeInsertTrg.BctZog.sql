create definer = ssg@localhost trigger userTbl_BeforeInsertTrg
    before insert
    on usertbl
    for each row
BEGIN
    IF NEW.birthYear < 1900 THEN
        SET NEW.birthYear = 0;
    ELSEIF NEW.birthYear > YEAR(CURDATE()) THEN
        SET NEW.birthYear = YEAR(CURDATE());
    END IF;

end;


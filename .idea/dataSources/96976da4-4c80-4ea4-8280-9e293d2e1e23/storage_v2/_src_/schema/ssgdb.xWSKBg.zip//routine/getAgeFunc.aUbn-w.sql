create
    definer = ssg@localhost function getAgeFunc(bYear int) returns int
BEGIN
    DECLARE age INT;
    SET age = YEAR(CURDATE()) - bYear;
    RETURN age;
end;


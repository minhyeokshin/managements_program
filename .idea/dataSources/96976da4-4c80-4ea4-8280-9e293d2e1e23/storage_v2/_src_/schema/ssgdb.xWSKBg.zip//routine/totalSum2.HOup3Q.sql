create
    definer = ssg@localhost procedure totalSum2()
BEGIN
    DECLARE result int;
    DECLARE i int;
    DECLARE savepointResult int;

    DECLARE EXIT HANDLER FOR 1264

    BEGIN
        SELECT CONCAT('INT 오버플로 직전의 합계 --> ',savepointResult),
        CONCAT('1+2+3+.....+ ',i,' = 오버플로');
    end ;

    set i = 1;
    set result = 0;

    while(true)
        Do
        SET savepointResult = result;
        SET result = result + i;
        SET i = i + 1;

        end while;

END;


create
    definer = ssg@localhost procedure p_insertcodes3(IN userID varchar(255), IN userPW varchar(255),
                                                     IN useremail varchar(255), IN hp varchar(255),
                                                     OUT resultMsg varchar(255))
BEGIN
    SET @ID =userID;
    SET @PW =userPW;
    SET @EMAIL =useremail;
    SET @HP =hp;
    SET resultMsg = '회원 정보가 안전하게 저장되었습니다.';
    -- 쿼리문 작성
        SET @strsql2 = 'INSERT INTO TB_MEMBER (m_userid, m_pwd, m_email, m_hp) VAlUES (?, ?, ?, ?);';

#     SET @strsql = CONCAT('INSERT INTO ', cTName, ' (cId, cName) ', ' SELECT COALESCE(MAX(cId),0) + 1 , ? FROM ', cTname );

    -- 바인딩할 변수 설정

    PREPARE stmt FROM @strsql2;
    EXECUTE stmt using @ID, @PW, @EMAIL, @HP;
    deallocate prepare stmt;

    COMMIT;
END;


create definer = ssg@localhost trigger backuUserTbl_DeleteTrg
    after delete
    on usertbl
    for each row
BEGIN
    INSERT INTO backup_userTbl VALUES (OLD.userID,OLD.name,OLD.birthYear,OLD.addr,OLD.mobile1,OLD.mobile2,OLD.height,OLD.mDate,'삭제',CURDATE(),CURRENT_USER());
end;


create
    definer = ssg@localhost function getAgeFunc2(bYear int) returns varchar(50)
BEGIN
    DECLARE age INT;
    DECLARE printage VARCHAR(50);
    SET age = YEAR(CURDATE()) - bYear;
    SET printage = concat(bYear,'년생은 ',YEAR(CURDATE()),'년 현재 ',age,'살입니다.');
    RETURN printage;
end;


create definer = ssg@localhost trigger prodTrg
    after update
    on prodTbl
    for each row
BEGIN
    DECLARE orderAmount INT;
    -- 주문 개수 = (변경 전의 개수 - 변경 후의 개수)
    SET orderAmount = OLD.account - NEW.account;
    INSERT INTO deliverTbl(prodName, account)
    VALUES(NEW.prodName, orderAmount);
END;


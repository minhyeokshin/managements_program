create
    definer = ssg@localhost procedure INPUT_Prod(IN Code varchar(50), IN Date datetime, IN State varchar(50))
BEGIN
    DECLARE maxnum INT;

    -- 최대 Prod_Num 찾기 (없으면 0으로 처리하고 +1)
    SELECT IFNULL(MAX(Prod_Num), 0) + 1 INTO maxnum
    FROM product_TB
    WHERE Prod_Code = Code;

    -- INSERT 문 생성
    SET @input = CONCAT('INSERT INTO product_TB (Prod_Code, Prod_Num, Prod_Date, State) VALUES (',
                        "'", Code, "', ", maxnum, ", '", Date, "', '", State, "')");

    -- 실행
    PREPARE stmt FROM @input;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

END;


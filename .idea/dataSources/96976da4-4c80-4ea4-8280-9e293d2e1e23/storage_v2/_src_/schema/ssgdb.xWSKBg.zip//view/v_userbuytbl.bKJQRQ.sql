create definer = ssg@localhost view v_userbuytbl as
select `u`.`userID` AS `userid`, `u`.`name` AS `name`, `u`.`addr` AS `addr`
from `ssgdb`.`usertbl` `u`;


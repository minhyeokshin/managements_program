create
    definer = ssg@localhost procedure delivProc(IN user_id varchar(20))
BEGIN

    SET @sqlQuery2 = concat('select userID, name , addr , mobile1 , mobile2 FROM usertbl WHERE userID = ','\'',user_id,'\'');
    PREPARE myQuery2 FROM @sqlQuery2;
    EXECUTE myQuery2;
    deallocate PREPARE myQuery2;

END;


create
    definer = ssg@localhost procedure nameTblProc(IN tblname varchar(20))
BEGIN
         SELECT * FROM tblname;

END;


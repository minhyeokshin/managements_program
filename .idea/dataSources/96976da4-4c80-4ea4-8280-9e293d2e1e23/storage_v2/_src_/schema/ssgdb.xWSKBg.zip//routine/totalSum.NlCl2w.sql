create
    definer = ssg@localhost procedure totalSum(IN min int, IN max int)
BEGIN
    DECLARE result int;
    DECLARE i int;
    SET i = min;
    set result = 0;

    WHILE(i <= max ) DO

            set result = result + i;
            set i = i + 1;
        END WHILE;

    select concat(min,'-',max,'의 총합은 ',result,'입니다.') as 'TotalSum';

END;

